# Bot de Telegram para consultas de precios, stock y avance

Este bot permite consultar información desde hojas de Google Sheets exportadas desde SQL Server, usando botones interactivos en Telegram.

## Funciones

- 🛒 Consultar precios por producto
- 📦 Ver stock por almacén
- 📈 Ver avance de clientes (solo administradores)

## Instalación

1. Clona el repositorio
2. Crea un archivo `.env` con tu token y claves
3. Instala dependencias:

```bash
pip install -r requirements.txt
